# Discovery-Piscine-Web


## Get Started
Welcome to Discovery Piscine - Web Edition. Your mission, if you choose to accept it, will be to start learning Web in the 42 way. For each exercise, use your brain, don't look up for the solution, and find your own solution.

## Additional Resources
- [Link to First Exercise](https://projects.intra.42.fr/projects/cellule0-0-shell)

### Discord
Have a question? Ask on Discord.

## File Structure
The file structure for this repository is as follows:

- cell0
  - ex00
    - something
  - ex01
    - something
  - ex02
    - something

- cell1
  - ex00
    - something
