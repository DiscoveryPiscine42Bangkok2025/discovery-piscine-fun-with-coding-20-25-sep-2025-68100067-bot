find . -maxdepth 1 -type f -or -type d | wc -l
